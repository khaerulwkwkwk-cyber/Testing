//credit By Limzzzhama 
//no hapus credit ketauan hapus hitam//

module.exports = {
  domain: "https://panelbyraflyshop.privatesrvr.xyz", // Ubah jadi Domain panel Mu !!!
  port: "19027" // Ubah Jadi Port Panel Mu !!!
};